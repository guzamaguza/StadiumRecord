# StadiumRecord-
This Sinatra application allows users to keep track of the MLB stadiums they have visited. 
